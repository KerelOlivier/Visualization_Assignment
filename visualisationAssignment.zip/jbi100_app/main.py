from dash import Dash


app = Dash(__name__)
app.title = "Visualizing the NYC Airbnb debate"
