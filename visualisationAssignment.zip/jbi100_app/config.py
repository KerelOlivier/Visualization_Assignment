# Here you can add any global configuations

color_list1 = ["green", "blue"]
color_list2 = ["red", "purple"]
